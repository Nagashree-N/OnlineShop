package com.niit.test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.dao.UserDAO;
import com.niit.model.User;
public class UserTest {
	public static void main(String arg[]) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		User user = (User) context.getBean("user");
		user.setId("UG120");
		user.setName("UGN120");
		user.setPassword("dscn");
		user.setMobile("123455");
		user.setMail("ncdccf@dnckdv");
		user.setAddress("hhgnv svnuh");
		userDAO.saveOrUpdate(user);
		user.setId("UG121");
		user.setName("UGNA121");
		user.setPassword("nvvnvn34");
		user.setMobile("156678");
		user.setMail("bdifh4@vcd");
		user.setAddress("nvkfnvf");
		userDAO.saveOrUpdate(user);
		user.setId("UG123");
		user.setName("pdohvd");
		user.setPassword("iffh");
		user.setMobile("85485");
		user.setAddress("ngnkjgn");
		user.setMail("fdk@bfdshb");
		userDAO.saveOrUpdate(user);
	//	userDAO.delete("CG122");
/*	if(userDAO.get("sgfsf")==null)
		{
			System.out.println("user doesnot exist");
		}
		else
		{
			System.out.println("user exist");
	*/	}
	}

