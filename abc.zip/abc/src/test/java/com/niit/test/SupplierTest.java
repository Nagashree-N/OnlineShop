package com.niit.test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.SupplierDAO;
import com.niit.model.Supplier;

public class SupplierTest {
	public static void main(String arg[]) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		Supplier supplier = (Supplier) context.getBean("supplier");
		supplier.setId("CG120");
		supplier.setName("CGN120");
		supplier.setAddress("CDGES121");
		supplierDAO.saveOrUpdate(supplier);
		supplier.setId("CG121");
		supplier.setName("CGNA121");
		supplier.setAddress("CSFs346");
		supplierDAO.saveOrUpdate(supplier);
	
		//supplierDAO.delete("CG120");
		/*if(supplierDAO.get("sdfsf")==null)
		{
			System.out.println("supplier doesnot exist");
		}
		else
		{
			System.out.println("supplier exist");
	*/	}
	}

