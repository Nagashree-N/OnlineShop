package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.dao.CategoryDAO;
import com.niit.model.Category;
public class CategoryTest {
	public static void main(String arg[]) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		Category category = (Category) context.getBean("category");
		category.setId("CG120");
		category.setName("CGN120");
		category.setDescription("CGDesc120");
		categoryDAO.saveOrUpdate(category);
		category.setId("CG121");
		category.setName("CGNA121");
		category.setDescription("CGDesc121");
		categoryDAO.saveOrUpdate(category);
		category.setId("CG122");
		category.setName("CGN122");
		category.setDescription("CGDesc122");
		category.setId("CG126");
		category.setName("CGN126");
		category.setDescription("CGDesc126");
		
		categoryDAO.saveOrUpdate(category);
				
	//	categoryDAO.delete("ro456");
		if(categoryDAO.get("CG126")==null)
		{
			System.out.println("category doesnot exist");
		}
		else
		{
			System.out.println("category exist");
	}
	}
}

