package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ShoppingCartSecurityController {
@RequestMapping(value={"/","/shoppingcarthome"},method=RequestMethod.GET)
public String homePage(ModelMap model)
{
	//model.addAttribute("user",getPrincipal());
	return "welcome";
}
@RequestMapping(value="/admin",method=RequestMethod.GET)
public String adminPage(ModelMap model)
{
	//model.addAttribute("user",getPrincipal());
	return "admin";
}
@RequestMapping(value="/super_admin",method=RequestMethod.GET)
public String superAdminPage(ModelMap model)
{
	//model.addAttribute("user",getPrincipal());
	return "super_admin";
}
@RequestMapping(value="/Access_Denied",method=RequestMethod.GET)
public String accessDeniedPage(ModelMap model)
{
	//model.addAttribute("user",getPrincipal());
	return "accessDenied";
}
@RequestMapping(value="/login",method=RequestMethod.POST)
public String loginPage()
{
	return "login";
}
}
