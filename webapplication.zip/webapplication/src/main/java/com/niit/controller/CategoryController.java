
package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

@Controller
public class CategoryController {
	private static final Logger logger = LoggerFactory.getLogger(CategoryController.class);
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private Category category;

	@RequestMapping(value = "category", method = RequestMethod.GET)
	public String listCategories(Model model) {
		logger.debug("starting of the method listcategories");
		model.addAttribute("category", category);
		model.addAttribute("categoryList", this.categoryDAO.list());
		logger.debug("ending of the method listcategories");
		return "redirect:/managecategory";
	}

	@RequestMapping(value = "/category/add", method = RequestMethod.POST)
	public String addCategory(@ModelAttribute("category") Category category) {
		logger.debug("starting of the method addcategory");
		categoryDAO.saveOrUpdate(category);
		logger.debug("ending of the method addcategory");
		return "redirect:/managecategory";
	}

	@RequestMapping("category/remove/{id}")
	public String deleteCategory(@PathVariable("id") String id, ModelMap model) throws Exception {
		categoryDAO.delete(id);
		return "redirect:/managecategory";

	}

	@RequestMapping("category/edit/{id}")
	public String editCategory(@PathVariable("id") String id, Model model) { // log.debug("Starting
																				// of
																				// the
																				// method
																				// editcategory");
																				// log.info("category
																				// id
																				// going
																				// edit
																				// is:"+id);
		category = categoryDAO.get(id);
		model.addAttribute("category", category);
		model.addAttribute("categoryList", categoryDAO.list());
		logger.debug("ending of the method editcategory");
		return "category";
	}
}
