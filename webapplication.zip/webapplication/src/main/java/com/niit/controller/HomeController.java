package com.niit.controller;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CategoryDAO;
import com.niit.dao.UserDAO;
import com.niit.model.Category;
import com.niit.model.User;

@Controller
public class HomeController {
	@Autowired
	User user;
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	Category category;
	//${categoryList}
	@RequestMapping("/")
		public ModelAndView onLoad(HttpSession session)
		{
		ModelAndView mv= new ModelAndView("/shoppingcarthome");
		System.out.println("hello");
        session.setAttribute("category",category);
        session.setAttribute("categoryList",categoryDAO.list());
        return mv;
		}
	//${successMessage}
	@RequestMapping(value="user/register",method=RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute User user){     
	userDAO.saveOrUpdate(user);
	ModelAndView mv=new ModelAndView("/shoppingcarthome");
	mv.addObject("sucessMessage","You are successfully registered");
	return mv;
	}
@RequestMapping("/register")
public ModelAndView registerHere()
{
	ModelAndView mv=new ModelAndView("/shoppingcarthome");
	mv.addObject("user",user);
	mv.addObject("isUserClickedRegisterHere",true);
	return mv;
}

@RequestMapping("/loginHere")
public ModelAndView loginHere()
{
	ModelAndView mv=new ModelAndView("/shoppingcarthome");
	mv.addObject("user",user);
	mv.addObject("isUserClickedLoginHere",true);
	return mv;
}
}
