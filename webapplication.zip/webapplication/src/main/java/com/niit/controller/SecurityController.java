package com.niit.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.User;

@Controller
public class SecurityController {
@RequestMapping(value={"/","/user**"},method=RequestMethod.GET)
public ModelAndView HomePage()
{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("shoppingcarthome");
	return mv;
}
@RequestMapping(value="/admin**",method=RequestMethod.GET)
public ModelAndView AdminPage()
{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("admin");
	return mv;
}
@RequestMapping(value={"/403"},method=RequestMethod.GET)
public ModelAndView AccessDenied()
{
	ModelAndView mv=new ModelAndView();
	Authentication auth=SecurityContextHolder.getContext().getAuthentication();
	if(!(auth instanceof AnonymousAuthenticationToken)){
		User user=(User)auth.getPrincipal();
		mv.addObject("username",user.getName());
	}
	mv.setViewName("403");
	return mv;
	}
}
