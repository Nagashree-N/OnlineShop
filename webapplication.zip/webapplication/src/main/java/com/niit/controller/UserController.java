package com.niit.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CartDAO;
import com.niit.dao.CategoryDAO;
import com.niit.dao.UserDAO;
import com.niit.model.Cart;
import com.niit.model.Category;
import com.niit.model.User;

@Controller
public class UserController {
	@Autowired
	UserDAO userDAO;

	@Autowired
	User user;
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private Category category;
	@Autowired
	private CartDAO cartDAO;
	@Autowired
	private Cart cart;
	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value="name")String userID, @RequestParam(value="password")String password,HttpSession session)
	{
		ModelAndView mv = new ModelAndView("shoppingcarthome");
		boolean isValidUser;
		isValidUser= userDAO.isVaildUser(userID,password);
		if(isValidUser==true){
			user=userDAO.get(userID);
		session.setAttribute("loggedInUser",user.getName());
		session.setAttribute("loggedInUserID", user.getId());
		if(user.getAdmin()==1)
		{
			mv.addObject("isAdmin","true");
		}
		else
		{
			mv.addObject("isAdmin","false");
			cart=cartDAO.get(userID);
			mv.addObject("cart",cart);
			List<Cart> cartList=cartDAO.list(userID);
			mv.addObject("cartList",cartList);
			mv.addObject("cartSize",cartList.size());
			}
	}else{
		mv.addObject("inValidUser",true);
		mv.addObject("errorMessage","invalidCredentials");
	}
		
		
		return mv;
	}
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request,HttpSession session)
	{  ModelAndView mv=new ModelAndView("/shoppingcarthome");
	session.invalidate();
	session=request.getSession(true);
	session.setAttribute("category",category);
	session.setAttribute("categoryList", categoryDAO.list());
	mv.addObject("logoutMessage","You successfully logged out");
	mv.addObject("loggedOut","true");
	return mv;
	}

}
