package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CategoryDAO;
import com.niit.dao.ProductDAO;
import com.niit.dao.SupplierDAO;
import com.niit.model.Category;
import com.niit.model.Product;
import com.niit.model.Supplier;

@Controller
public class AdminController {
@Autowired
private Product product;
@Autowired
private Category category;
@Autowired
private Supplier supplier;
@Autowired
private CategoryDAO categoryDAO;
@Autowired
private SupplierDAO supplierDAO;
@Autowired
private ProductDAO productDAO;
@RequestMapping("/managecategory")
public ModelAndView categories()
{ModelAndView mv=new ModelAndView("/shoppingcarthome");
mv.addObject("category",category);
mv.addObject("isAdminClickedCategories","true");
mv.addObject("categoryList",this.categoryDAO.list());
return mv;
}
@RequestMapping("/manageproducts")
public ModelAndView supplier()
{
	ModelAndView mv=new ModelAndView("/shoppingcarthome");
	mv.addObject("product",product);
	mv.addObject("isAdminClickedProducts","true");
	mv.addObject("productList",this.productDAO.list());
	return mv;
	
}
@RequestMapping("/managesupplier")
public ModelAndView products()
{
	ModelAndView mv=new ModelAndView("/shoppingcarthome");
	mv.addObject("supplier",supplier);
	mv.addObject("isAdminClickedSuppliers","true");
	mv.addObject("supplierList",this.supplierDAO.list());
	return mv;
}

}
