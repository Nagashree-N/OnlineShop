package com.niit.controller;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.niit.dao.CategoryDAO;
import com.niit.dao.ProductDAO;
import com.niit.dao.SupplierDAO;
import com.niit.model.Category;
import com.niit.model.Product;
import com.niit.model.Supplier;
import com.niit.model.Item;
import com.niit.dao.ItemDAO;
import com.niit.model.Cart;
import com.niit.dao.CartDAO;


@Controller
public class ProductController {
	private static final Logger logger=LoggerFactory.getLogger(ProductController.class);
	@Autowired(required=true)
	ProductDAO productDAO;
	@Autowired
	Product product;
	@Autowired(required=true)
	CategoryDAO categoryDAO;
	@Autowired
	Category category;
	@Autowired(required=true)
	SupplierDAO supplierDAO;
	@Autowired
	Supplier supplier;
	@Autowired
	Item items;
	@Autowired
	ItemDAO itemDAO;
	@Autowired
	CartDAO cartDAO;
	@Autowired
	Cart cart;
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public String listProducts(Model model)
	{ logger.debug("starting of the method listproducts");
	model.addAttribute("product",new Product());
	model.addAttribute("category",new Category());
	model.addAttribute("supplier",new Supplier());
	model.addAttribute("productList",this.productDAO.list());
	model.addAttribute("categoryList",this.categoryDAO.list());
	model.addAttribute("supplierList",this.supplierDAO.list());
	model.addAttribute("productList",this.productDAO.list());
	logger.debug("ending of the method listproducts");
	return "redirect:/manageproducts";
	}
	@RequestMapping(value="/product/add",method=RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product)
	{	Category category=categoryDAO.get(product.getCategory().getName());
	Supplier supplier=supplierDAO.get(product.getSupplier().getName());
	product.setCategory(category);
	product.setId(category.getId());
	product.setSupplier(supplier);
	product.setId(supplier.getId());
		productDAO.saveOrUpdate(product);
	//MultipartFile file=product.getImage();
	//FileUtil.upload(path, file, product.getId()+".jpg");
		return "redirect:/manageproducts";
	}
	@RequestMapping("product/remove/{id}")
	public String deleteProduct(@PathVariable("id") String id, ModelMap model) throws Exception {
		try{
		productDAO.delete(id);
		model.addAttribute("message","Successfully deleted");
		}
		catch(Exception e){
			model.addAttribute("message",e.getMessage());
			e.printStackTrace();
		}
		return "redirect:/manageproducts";

	}
	@RequestMapping("product/edit/{id}")
	public String editProduct(@PathVariable("id") String id, Model model) { // log.debug("Starting
																				// of
		
																				// the
																				// method
																				// editproduct");
																				// log.info("product
																				// id
																				// going
																				// edit
																				// is:"+id);
		product = productDAO.get(id);
		model.addAttribute("product", product);
		model.addAttribute("productList", productDAO.list());
		model.addAttribute("categoryList",categoryDAO.list());
		model.addAttribute("supplierList",supplierDAO.list());
		 logger.debug("ending of the method editproduct");
		return "product";
	}
	@RequestMapping(value="/product/get/{id}")
	public String getProduct(@PathVariable("id") String id,Model model,HttpSession session)
	{
	product=productDAO.get(id);
	items=itemDAO.get(id);
	model.addAttribute("product",product);
	model.addAttribute("productList",this.productDAO.list());
	model.addAttribute("items",items);
	model.addAttribute("itemList",this.itemDAO.list());
	model.addAttribute("isAdmin",false);
	model.addAttribute("cartSize", cartDAO.list(id).size());
	model.addAttribute("selectedItems",true);
	return "/shoppingcarthome";
	}
	}
	
