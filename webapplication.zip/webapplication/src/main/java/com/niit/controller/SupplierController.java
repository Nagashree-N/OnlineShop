package com.niit.controller;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.niit.dao.SupplierDAO;
import com.niit.model.Supplier;
import com.niit.model.Supplier;
@Controller
public class SupplierController {
	
		private static final Logger logger = LoggerFactory.getLogger(SupplierController.class);
		@Autowired
		private SupplierDAO supplierDAO;
		@Autowired
		private Supplier supplier;

		@RequestMapping(value = "supplier", method = RequestMethod.GET)
		public String listSupplier(Model model) {
			logger.debug("starting of the method listsupplier");
			model.addAttribute("supplier", supplier);
			model.addAttribute("supplierList", this.supplierDAO.list());
			logger.debug("ending of the method listsupplier");
			return "redirect:/managesupplier";
		}
		@RequestMapping(value = "/supplier/add", method = RequestMethod.POST)
		public String addSupplier(@ModelAttribute("supplier") Supplier supplier) {
			logger.debug("starting of the method add supplier");
			supplierDAO.saveOrUpdate(supplier);
			logger.debug("ending of the method addsupplier");
			return "redirect:/managesupplier";
		}

		@RequestMapping("supplier/remove/{id}")
		public String deleteSupplier(@PathVariable("id") String id, ModelMap model) throws Exception {
			supplierDAO.delete(id);
			return "redirect:/managesupplier";

		}

		@RequestMapping("supplier/edit/{id}")
		public String editSupplier(@PathVariable("id") String id, Model model) { // log.debug("Starting
																					// of
																					// the
																					// method
																					// editsupplier");
																					// log.info("supplier
																					// id
																					// going
																					// edit
																					// is:"+id);
			supplier = supplierDAO.get(id);
			model.addAttribute("supplier", supplier);
			model.addAttribute("supplierList", supplierDAO.list());
			logger.debug("ending of the method editsupplier");
			return "supplier";
		}

}
