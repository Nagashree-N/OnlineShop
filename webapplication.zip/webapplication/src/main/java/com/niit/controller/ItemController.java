package com.niit.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.niit.dao.CartDAO;
import com.niit.dao.CategoryDAO;
import com.niit.dao.ItemDAO;
import com.niit.dao.SupplierDAO;
import com.niit.model.Cart;
import com.niit.model.Category;
import com.niit.model.Item;
import com.niit.model.Supplier;

	@Controller
	public class ItemController {
		private static final Logger logger=LoggerFactory.getLogger(ItemController.class);
		@Autowired(required=true)
		ItemDAO itemDAO;
		@Autowired
		Item item;
		@Autowired(required=true)
		CategoryDAO categoryDAO;
		@Autowired
		Category category;
		@Autowired(required=true)
		SupplierDAO supplierDAO;
		@Autowired
		Supplier supplier;
		@Autowired
		CartDAO cartDAO;
		@Autowired
		Cart cart;
		@RequestMapping(value="/items", method=RequestMethod.GET)
		public String listItems(Model model)
		{ logger.debug("starting of the method listitems");
		model.addAttribute("item",new Item());
		model.addAttribute("category",new Category());
		model.addAttribute("supplier",new Supplier());
		model.addAttribute("itemList",this.itemDAO.list());
		model.addAttribute("categoryList",this.categoryDAO.list());
		model.addAttribute("supplierList",this.supplierDAO.list());
		model.addAttribute("itemList",this.itemDAO.list());
		logger.debug("ending of the method listitems");
		return "redirect:/manageitems";
		}
		@RequestMapping(value="/item/add",method=RequestMethod.POST)
		public String addItem(@ModelAttribute("item") Item item)
		{	
			itemDAO.saveOrUpdate(item);
		//MultipartFile file=item.getImage();
		//FileUtil.upload(path, file, item.getId()+".jpg");
			return "redirect:/manageitems";
		}
		@RequestMapping("item/remove/{id}")
		public String deleteItem(@PathVariable("id") String id, ModelMap model) throws Exception {
			try{
			itemDAO.delete(id);
			model.addAttribute("message","Successfully deleted");
			}
			catch(Exception e){
				model.addAttribute("message",e.getMessage());
				e.printStackTrace();
			}
			return "redirect:/manageitems";

		}
		@RequestMapping("item/edit/{id}")
		public String editItem(@PathVariable("id") String id, Model model) { // log.debug("Starting
																					// of
			
																					// the
																					// method
																					// edititem");
																					// log.info("item
																					// id
																					// going
																					// edit
																					// is:"+id);
			item = itemDAO.get(id);
			model.addAttribute("item", item);
			model.addAttribute("itemList", itemDAO.list());
			model.addAttribute("categoryList",categoryDAO.list());
			model.addAttribute("supplierList",supplierDAO.list());
			 logger.debug("ending of the method edititem");
			return "item";
		}
		@RequestMapping(value="/item/get/{id}")
		public String getItem(@PathVariable("id") String id,Model model,HttpSession session)
		{
		item=itemDAO.get(id);
		item=itemDAO.get(id);
		model.addAttribute("item",item);
		model.addAttribute("itemList",this.itemDAO.list());
		model.addAttribute("item",item);
		model.addAttribute("itemList",this.itemDAO.list());
		model.addAttribute("isAdmin",false);
		model.addAttribute("cartSize", cartDAO.list(id).size());
		model.addAttribute("selectedItems",true);
		return "/shoppingcarthome";
		}
	
}
