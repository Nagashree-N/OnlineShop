package com.niit.dao;
import java.util.*;

import com.niit.model.Item;

public interface ItemDAO {
	public List<Item> list();

	public Item get(String id);

	public void saveOrUpdate(Item item);

	public void delete(String id);
}
