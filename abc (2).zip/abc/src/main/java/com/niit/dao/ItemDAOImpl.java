package com.niit.dao;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Item;

@Repository("itemDAO")
public class ItemDAOImpl implements ItemDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	public ItemDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(Item item) {
		sessionFactory.getCurrentSession().saveOrUpdate(item);

	}
	@Transactional
	public void delete(String id) {
		Item item = new Item();
		item.setId(id);
		sessionFactory.getCurrentSession().delete(item);
	}

	@Transactional
	public Item get(String id) {
		String hql = "from Item where id=" + "'" + id+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Item> listItem = (List<Item>) query.list();
		if (listItem != null && !listItem.isEmpty()) {
			return listItem.get(0);
		}
		return null;
	}
	@Transactional
	public List<Item> list() {
		@SuppressWarnings("unchecked")
		List<Item> listItem = (List<Item>) sessionFactory.getCurrentSession().createCriteria(Item.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listItem;

	}

}
