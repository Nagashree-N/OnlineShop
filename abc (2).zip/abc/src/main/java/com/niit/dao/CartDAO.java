package com.niit.dao;

import java.util.List;
import com.niit.model.Cart;
import com.niit.model.Category;

public interface CartDAO {
	public List<Cart> list(String id);
	public void saveOrUpdate(Cart cart);
	public Cart get(String id);
	public String delete(String id);
	//public Long getTotalAmount(String id);

}
