package com.niit.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

public class TestCategoryDAO {

	static CategoryDAO categoryDAO;
	static Category category;
	 static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
		category=(Category)context.getBean("category");
	}
	@AfterClass
	public static void close()
	{
		context.close();
		categoryDAO=null;
		category=null;
	}
	@Test
	public void categoryTestCase()
	{
		int size=categoryDAO.list().size();
		assertEquals("Category list  test case",7,size);
	}
	@Test
	public void userNameTestCase()
	{
		category= categoryDAO.get("CG121");
		String name=category.getName();
		assertEquals("Name test case","CGNA121",name);
	}
	
		
	

}
