package com.niit.test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.dao.ProductDAO;
import com.niit.model.Product;
public class ProductTest {
	public static void main(String arg[]) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		Product product = (Product) context.getBean("product");
		product.setId("PG120");
		product.setName("PGN120");
		product.setDescription("PGDEsc120");
		product.setPrice("1243");
		productDAO.saveOrUpdate(product);
		product.setId("PG121");
		product.setName("PGNA121");
		product.setDescription("PDEsc121");
		product.setPrice("4935");
		productDAO.saveOrUpdate(product);
		product.setId("PG122");
		product.setName("PGN122");
		product.setDescription("PDesc122");
		productDAO.saveOrUpdate(product);
		
		//	productDAO.delete("ro456");
			if(productDAO.get("PG122")==null)
			{
				System.out.println("product doesnot exist");
			}
			else
			{
				System.out.println("product exist");
			}
	}
}
