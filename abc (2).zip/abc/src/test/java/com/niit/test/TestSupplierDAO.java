package com.niit.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.SupplierDAO;
import com.niit.model.Supplier;

public class TestSupplierDAO {
 static SupplierDAO supplierDAO;
 static Supplier supplier;
static AnnotationConfigApplicationContext context;
@BeforeClass
public  static void init()
{
	context=new AnnotationConfigApplicationContext();
	context.scan("com.niit");;
	context.refresh();
	supplierDAO=(SupplierDAO) context.getBean("supplierDAO");
	supplier=(Supplier)context.getBean("supplier");
}
@AfterClass
public static void close()
{
	context.close();
	supplierDAO=null;
	supplier=null;
}
@Test
public void supplierTestCase()
{
	int size=supplierDAO.list().size();
	assertEquals("Supplier list test case", 4,size);
	
}
@Test
public void SupplierNameTestCase()
{
	supplier=supplierDAO.get("CG121");
	String name=supplier.getName();
	assertEquals("Name test case","CGNA121",name);

}
	
}
