package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.dao.ItemDAO;
import com.niit.model.Item;
public class ItemTest {
	public static void main(String arg[]) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		ItemDAO itemDAO = (ItemDAO) context.getBean("itemDAO");
		Item item = (Item) context.getBean("item");
		item.setId("IT-1");
		item.setName("CGN120");
		item.setDescription("CGDesc120");
		item.setPrice("3500.00");
		itemDAO.saveOrUpdate(item);
		
				
	//	itemDAO.delete("ro456");
		if(itemDAO.get("CG126")==null)
		{
			System.out.println("item doesnot exist");
		}
		else
		{
			System.out.println("item exist");
	}
	}
}

