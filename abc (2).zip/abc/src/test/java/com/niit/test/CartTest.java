package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;

public class CartTest {
	public static void main(String arg[]) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		Cart cart = (Cart) context.getBean("cart");
		cart.setId("CG120");
		cart.setQuantity(1);
		cart.setStatus("N");
		cartDAO.saveOrUpdate(cart);
		cart.setId("CG121");
		cart.setQuantity(1);
		cart.setStatus("N");
		cartDAO.saveOrUpdate(cart);
	
				
	//	cartDAO.delete("ro456");
		if(cartDAO.get("CG126")==null)
		{
			System.out.println("cart doesnot exist");
		}
		else
		{
			System.out.println("cart exist");
	}
	}
}
