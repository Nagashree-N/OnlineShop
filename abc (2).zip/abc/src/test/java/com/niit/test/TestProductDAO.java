package com.niit.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.ProductDAO;
import com.niit.model.Product;

public class TestProductDAO {

	 static ProductDAO productDAO;
	 static Product product;
	static AnnotationConfigApplicationContext context;
	@BeforeClass
	public  static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		productDAO=(ProductDAO) context.getBean("productDAO");;
		product=(Product)context.getBean("product");
	}
	@AfterClass
	public static void close()
	{
		context.close();
		productDAO=null;
		product=null;
	}
	@Test
	public void ProductTestCase()
	{
		int size=productDAO.list().size();
		assertEquals("Product list test case",2 ,size);
		
	}
	/*@Test
	public void ProductNameTestCase()
	{
		product=productDAO.get("PG120");
		String name=product.getName();
		assertEquals("Name test case","PGN120",name);
	
	}*/
}
