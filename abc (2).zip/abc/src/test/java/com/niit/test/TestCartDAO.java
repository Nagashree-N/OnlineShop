package com.niit.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;

public class TestCartDAO {
	static CartDAO cartDAO;
	static Cart cart;
	 static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		cartDAO=(CartDAO) context.getBean("cartDAO");
		cart=(Cart)context.getBean("cart");
	}
	@AfterClass
	public static void close()
	{
		context.close();
		cartDAO=null;
		cart=null;
	}
	@Test
	public void cartTestCase()
	{
		int size=cartDAO.list(null).size();
		assertEquals("Cart list  test case",0,size);
	}
	/*@Test
	public void userNameTestCase()
	{
		cart= cartDAO.get("CG121");
		String name=cart.get();
		assertEquals("Name test case","CGNA121",name);
	}*/
	
}
